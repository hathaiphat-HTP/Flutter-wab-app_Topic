package com.example.chapter4_cloud_firestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
